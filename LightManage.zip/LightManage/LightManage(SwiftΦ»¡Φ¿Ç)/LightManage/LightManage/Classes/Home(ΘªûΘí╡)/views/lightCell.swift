//
//  lightCell.swift
//  LightManageYWJ
//
//  Created by qwe on 2022/6/16.
//

import UIKit

class lightCell: UITableViewCell {
    
    @IBOutlet weak var lightName: UILabel!
    @IBOutlet weak var lightPrice: UILabel!
    @IBAction func detailButton(_ sender: Any) {
        
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
