//
//  lightKindCell.swift
//  LightManageYWJ
//
//  Created by qwe on 2022/6/17.
//

import UIKit

class lightKindCell: UITableViewCell {
    @IBOutlet weak var lightKindName: UILabel!
    @IBOutlet weak var lightKindId: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
