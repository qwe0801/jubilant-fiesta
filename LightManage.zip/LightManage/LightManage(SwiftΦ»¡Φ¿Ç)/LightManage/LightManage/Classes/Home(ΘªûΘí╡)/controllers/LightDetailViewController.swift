//
//  LightDetailViewController.swift
//  LightManageYWJ
//
//  Created by qwe on 2022/6/16.
//

import UIKit
import SVProgressHUD
import Alamofire

class LightDetailViewController: UIViewController {
    
    @IBOutlet weak var lightID: UITextField!
    
    @IBOutlet weak var lightKindID: UITextField!
    
    @IBAction func updatebutton(_ sender: Any) {
    }
    @IBOutlet weak var lightPrice: UITextField!
    @IBOutlet weak var lightName: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title="图书详情"
        getLight()
    }
    var lightId: Int?
    var lights: lightModel?
    var light: [lightBaseModel]?
    func getLight() {
            SVProgressHUD.show(withStatus: "加载中")
            let parameters:Parameters = [
               "lightId":self.lightId!
            ]
            LightNetwork.findLightById(parameters: parameters) { response in
                print(response)
                self.lights = lightModel(JSON: response)
                self.light = self.lights?.result
                for item in self.light! {
                    self.lightID.text = (item.lightID!).description
                    self.lightKindID.text = (item.lightKindId!).description
                    self.lightName.text = item.lightName
                    self.lightPrice.text = item.lightPrice
                }
                SVProgressHUD.dismiss()
            } failture: {
                print("发生错误：\(#function)")
            }
        }
}
