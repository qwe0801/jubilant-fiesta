//
//  LightViewController.swift
//  LightManageYWJ
//
//  Created by qwe on 2022/6/17.
//

import UIKit
import SVProgressHUD
import Alamofire

class LightViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var lightTableView: UITableView!
    
    //设备tableView的数据源
    var lightModelArray:lightModel?
    var lightBaseModelArray:[lightBaseModel]?
   
    var classIdArray:[Int] = []
    var lightIdArray:[Int] = []
    var lightNameArray:[String] = []
    var lightPriceArray:[String] = []
   
    var lightKindId:Int?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title="灯具列表"
        self.setupUI()
    }
    
    func setupUI() {
        self.setupTableView()
    }
    
    func setupTableView() {
       self.view.addSubview(self.lightTableView)
       self.getAllLightByLightKindId()
        
       self.lightTableView.delegate = self
       self.lightTableView.dataSource = self
        
       self.lightTableView.tableFooterView = UIView()
       self.lightTableView.register(UINib(nibName: "lightCell",bundle: nil), forCellReuseIdentifier: "lightCell")
    }
    
     func getAllLightByLightKindId() {
         SVProgressHUD.show(withStatus: "加载中")
         let parameters:Parameters = [
            "lightKindId":self.lightKindId!
         ]
         LightNetwork.findLightByLightKindId(parameters: parameters,finishedCallback: { (response) in
             // 清空数组
             self.classIdArray = []
             self.lightIdArray = []
             self.lightNameArray = []
             self.lightPriceArray = []
 
             self.lightModelArray = lightModel(JSON: response)
             self.lightBaseModelArray = self.lightModelArray?.result
            for item in self.lightBaseModelArray! {
                self.classIdArray.append(item.lightKindId!)
                self.lightIdArray.append(item.lightID!)
                self.lightNameArray.append(item.lightName!)
                self.lightPriceArray.append(item.lightPrice!)
             }
             SVProgressHUD.dismiss()
             self.lightTableView.reloadData()
         }) {
             print("发生错误：\(#function)")
         }
     }
    //MARK: -实现UITableDataSource协议
    
    func tableView(_ tableView: UITableView,titleForHeaderInSection section: Int) -> String? {
        return "灯具列表"
    }
    func numberOfSections(in tableView:UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
            return 40
    }
    func tableView(_ tableView: UITableView,numberOfRowsInSection section: Int) -> Int {
        if self.lightBaseModelArray != nil {
            return lightNameArray.count
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "lightCell", for:indexPath) as! lightCell
        
        if self.lightModelArray != nil {
            cell.lightName.text = self.lightNameArray[indexPath.row]
            cell.lightPrice.text = self.lightPriceArray[indexPath.row]
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView,didSelectRowAt indexPath: IndexPath) {
    tableView.deselectRow(at: indexPath,animated: true)
    let vc = LightDetailViewController()
        vc.lightId = lightIdArray[indexPath.row]
        vc.hidesBottomBarWhenPushed = true
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
