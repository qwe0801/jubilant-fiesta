//
//  HomeViewController.swift
//  LightManageYWJ
//
//  Created by qwe on 2022/6/16.
//

import UIKit
import Alamofire
import SDCycleScrollView
import SVProgressHUD
import SnapKit
 
class HomeViewController: UIViewController,UITableViewDelegate,UITableViewDataSource{
    
    @IBOutlet weak var lightKindTableView: UITableView!
    
    //分类collectionView的数据源
    var lightKindModelArray:lightKindModel?
    var lightKindBaseModelArray:[lightKindBaseModel]?
    //设备tableView的数据源
    var lightModelArray:lightModel?
    var lightBaseModelArray:[lightBaseModel]?
   
    var classIdArray:[Int] = []
    var classNameArray:[String] = []
    var lightIdArray:[Int] = []
    var lightNameArray:[String] = []
    var lightPriceArray:[String] = []
   
    var lightKindNames:[String]?
    var lightKindIds:[Int]?
   
    var lightKindId:Int?
       
    override func viewDidLoad() {
        super.viewDidLoad()
        self.edgesForExtendedLayout = .bottom
        self.title = "首页"
        self.setupUI()
    }
   
    func setupUI() {
        self.setupTableView()
    }
    
    func setupTableView() {
       self.view.addSubview(self.lightKindTableView)
       self.getAllLightKind()
        
       self.lightKindTableView.delegate = self
       self.lightKindTableView.dataSource = self
        
       self.lightKindTableView.tableFooterView = UIView()
       self.lightKindTableView.register(UINib(nibName: "lightKindCell",bundle: nil), forCellReuseIdentifier: "lightKindCell")
    }
    
    func getAllLightKind() {
        SVProgressHUD.show(withStatus: "加载中")
        LightKindNetwork.getAllLightKind(finishedCallback: { (response) in
            print(response)
            self.lightKindNames = []
            self.lightKindIds = []
           
            self.lightKindModelArray = lightKindModel(JSON: response)
            self.lightKindBaseModelArray = self.lightKindModelArray?.result
            for item in self.lightKindBaseModelArray! {
               self.lightKindNames?.append(item.LightKindName ?? "")
               self.lightKindIds?.append(item.LightKindID!)
            }
            SVProgressHUD.dismiss()
           self.lightKindTableView.reloadData()
        }) {
            print("发生错误：\(#function)")
        }
    }

    //MARK: -实现UITableDataSource协议
    func tableView(_ tableView: UITableView,titleForHeaderInSection section: Int) -> String? {
        return "灯具分类"
    }
   
    func numberOfSections(in tableView:UITableView) -> Int {
        return 1
    }
   
    func tableView(_ tableView: UITableView,numberOfRowsInSection section: Int) -> Int {
        if self.lightKindNames != nil {
            return self.lightKindNames!.count
        }
        return 0
    }
    func tableView(_ tableView: UITableView,heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 40
    }
    func tableView(_ tableView: UITableView,cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier:"lightKindCell", for: indexPath) as! lightKindCell
        if self.lightKindModelArray != nil {
            cell.lightKindName.text = self.lightKindNames![indexPath.row]
            cell.lightKindId.text = String(self.lightKindIds![indexPath.item])
        }
        return cell
    }
    
     func tableView(_ tableView: UITableView,didSelectRowAt indexPath: IndexPath) {
         tableView.deselectRow(at: indexPath,animated: true)
         let vc = LightViewController()
         vc.lightKindId = lightKindIds?[indexPath.row]
         vc.hidesBottomBarWhenPushed = true
        self.navigationController?.pushViewController(vc, animated: true)
     }
}
