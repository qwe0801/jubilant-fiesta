//
//  lightModel.swift
//  LightManageYWJ
//
//  Created by qwe on 2022/6/16.
//

import Foundation
import ObjectMapper
 
class lightModel: Mappable {
    var result:[lightBaseModel]?
   
    required init?(map: Map) {
       
    }
   
    func mapping(map: Map) {
        result <- map["result"]
    }
   
}
 
class lightBaseModel: Mappable {
   
    var lightKindId:Int?
    var lightID:Int?
    var lightName:String?
    var lightPrice:String?
   
    required init?(map: Map) {
       
    }
   
    func mapping(map: Map) {
        lightKindId    <- map["LightKindId"]
        lightID        <- map["LightID"]
        lightName      <- map["LightName"]
        lightPrice     <- map["LightPrice"]
    }
   
}


