//
//  lightKindModel.swift
//  LightManageYWJ
//
//  Created by qwe on 2022/6/16.
//

import Foundation
import ObjectMapper

class  lightKindModel:Mappable{
    var result:[lightKindBaseModel]?
    required init?(map: Map) {
    }
    func mapping(map: Map) {
        result <- map["result"]
    }
}
class  lightKindBaseModel:Mappable {
    var LightKindID:Int?
    var LightKindName:String?
    required init?(map: Map) {
    }
    func mapping(map: Map) {
        LightKindID   <- map["LightKindID"]
        LightKindName <- map["LightKindName"]
    }
}
