//
//  LightKindNetwork.swift
//  LightManageYWJ
//
//  Created by qwe on 2022/6/16.
//

import Foundation
class LightKindNetwork {
    static func getAllLightKind(finishedCallback: @escaping (_ result:[String: Any]) -> (),failture: @escaping ()->()) {
        let url = GlobalDefine.baseURL  + "findAllLightKind"
        NetworkTool.shareInstance.requestJsonData(.get, URLString: url) { response in
            finishedCallback(response)
        } failture: { _ in
            failture()
        }
    }
    
}

