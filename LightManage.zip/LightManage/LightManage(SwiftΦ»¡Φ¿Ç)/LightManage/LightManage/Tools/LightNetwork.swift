//
//  LightNetwork.swift
//  LightManageYWJ
//
//  Created by qwe on 2022/6/16.
//

import Foundation
class LightNetwork {
    static func findLightById(parameters:[String:Any]? = nil,
                              finishedCallback: @escaping (_ result:[String:Any])->(),
                              failture: @escaping ()->()) {
            let url = GlobalDefine.baseURL + "findLightById"
            NetworkTool.shareInstance.requestJsonData(.get, URLString: url, parameters: parameters, success: {
                (response) in
                print(response)
                finishedCallback(response)
            }) {
                (_) in
                failture()
            }
        }
    static func findLightByLightKindId(parameters:[String:Any]? = nil,
                              finishedCallback: @escaping (_ result:[String:Any])->(),
                              failture: @escaping ()->()) {
            let url = GlobalDefine.baseURL + "findLightByLightKindId"
            NetworkTool.shareInstance.requestJsonData(.get, URLString: url, parameters: parameters, success: {
                (response) in
                print(response)
                finishedCallback(response)
            }) {
                (_) in
                failture()
            }
        }
    static func updateLightById(parameters:[String:Any]? = nil,
                          finishedCallback: @escaping (_ result:[String:Any])->(),
                          failture: @escaping ()->()) {
        let url = GlobalDefine.baseURL + "updateLightById"
        NetworkTool.shareInstance.requestJsonData(.get, URLString: url, parameters: parameters, success: {
            (response) in
            print(response)
            finishedCallback(response)
        }) {
            (_) in
            failture()
        }
    }
}
