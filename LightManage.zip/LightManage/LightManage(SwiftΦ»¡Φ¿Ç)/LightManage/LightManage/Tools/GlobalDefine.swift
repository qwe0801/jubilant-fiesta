//
//  GlobalDefine.swift
//  LightManageYWJ
//
//  Created by qwe on 2022/6/16.
//

import UIKit
import Alamofire

class GlobalDefine:NSObject {
    // API基础网址
    static let baseURL = "http://192.168.1.101:8080/LightManage/"

    //状态栏 + 导航栏高度
    static let naviHeight = UINavigationController().navigationBar.frame.height + UIApplication.shared.statusBarFrame.height
    //tabbar高度
    static let tabbarHeight = UITabBar().frame.height
}

let ScreenWidth = UIScreen.main.bounds.width
let ScreenHeight = UIScreen.main.bounds.height

