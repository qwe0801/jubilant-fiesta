//
//  UserNetwork.swift
//  DeviceManage
//
//  Created by zjc14 on 2022/5/5.
//

import UIKit

class UserNetwork: NSObject {
    /// 用户登录
       /// - Parameters:
       ///   - parameters: 发送参数
       ///   - finishedCallback: 获取成功后回调
       ///   - failture: 获取失败后回调
       static func loginValidate(parameters:[String:Any]? = nil,
                             finishedCallback: @escaping (_ result:[String:Any])->(),
                             failture: @escaping ()->()) {
           let url = GlobalDefine.baseURL + "loginValidate"
           NetworkTool.shareInstance.requestJsonData(.post, URLString: url, parameters: parameters, success: {
               (response) in
               finishedCallback(response)
           }) {
               (_) in
               failture()
           }
       }

}
