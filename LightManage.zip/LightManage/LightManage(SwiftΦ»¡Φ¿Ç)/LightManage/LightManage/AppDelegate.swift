//
//  AppDelegate.swift
//  LightManageYWJ
//
//  Created by qwe on 2022/6/16.
//

import UIKit

@main
class AppDelegate: UIResponder, UIApplicationDelegate {
    var window:UIWindow?
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        self.window = UIWindow(frame: UIScreen.main.bounds)
        self.window?.backgroundColor = UIColor.white
        let rootVC = MainViewController()

        
        self.window?.rootViewController = rootVC
        self.window?.makeKeyAndVisible()

        return true
    }
}

