package zjc.manage.web;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import zjc.manage.dao.LightMapper;
import zjc.manage.domain.Light;
import zjc.manage.domain.LightExample;
import javax.annotation.Resource;
import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/LightManage")
public class LightController {

    @Resource
    private LightMapper lightMapper;

    @GetMapping("/findAllLight")
    public Object findAllLight() throws IOException {
        LightExample example = new LightExample();
        List<Light> list = lightMapper.selectByExample(example);
        return makeJson(list);
    }

    @GetMapping("/findLightByLightKindId")
    public Object findLightByLightKindId(int lightKindId) throws IOException {
        LightExample example = new LightExample();
        LightExample.Criteria criteria = example.createCriteria();
        criteria.andLightkindidEqualTo(lightKindId);
        List<Light> list = lightMapper.selectByExample(example);
        return makeJson(list);
    }

    @GetMapping("/findLightById")
    public Object findLightById(int lightId) throws IOException {
        LightExample example = new LightExample();
        LightExample.Criteria criteria = example.createCriteria();
        criteria.andLightidEqualTo(lightId);
        List<Light> list = lightMapper.selectByExample(example);
        return makeJson(list);
    }

    public Object makeJson(List<Light> list) throws IOException{
        JSONArray jsonArray = new JSONArray();
        for(Light dev: list){
            JSONObject jsonObj = new JSONObject();
            jsonObj.put("LightID", dev.getLightid());
            jsonObj.put("LightKindId", dev.getLightkindid());
            jsonObj.put("LightName", dev.getLightname());
            jsonObj.put("LightPrice", dev.getLightprice());
            jsonArray.add(jsonObj);
        }
        System.out.println(jsonArray.toString());
        JSONObject root = new JSONObject();
        root.put("result", jsonArray);
        return root;
    }
}
