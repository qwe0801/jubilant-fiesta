package zjc.manage.service;

public class LightService {
}
