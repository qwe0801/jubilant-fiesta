package zjc.manage.web;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import zjc.manage.dao.LightkindMapper;
import zjc.manage.domain.Lightkind;
import zjc.manage.domain.LightkindExample;
import javax.annotation.Resource;
import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/LightManage")
public class LightKindController {


    @Resource
    private LightkindMapper lightkindMapper;

    @GetMapping("/findAllLightKind")
    public Object findAllLightKind() throws IOException {
        LightkindExample example = new LightkindExample();
        List<Lightkind> list = lightkindMapper.selectByExample(example);
        return makeJson(list);
    }

    @GetMapping("/findLightKind")
    public Object findLightKind(int lightkindId) throws IOException{

        LightkindExample example = new LightkindExample();
        example.or().andLightkindidEqualTo(lightkindId);
        List<Lightkind> list = lightkindMapper.selectByExample(example);
        return makeJson(list);
    }

    public Object makeJson(List<Lightkind> list) throws IOException {

        JSONArray jsonArray = new JSONArray();
        for (Lightkind dc : list) {
            JSONObject jsonObj = new JSONObject();
            jsonObj.put("LightKindID", dc.getLightkindid());
            jsonObj.put("LightKindName", dc.getLightkindname());
            jsonArray.add(jsonObj);
        }

        JSONObject root = new JSONObject();
        root.put("result", jsonArray);
        return root;
    }


}
