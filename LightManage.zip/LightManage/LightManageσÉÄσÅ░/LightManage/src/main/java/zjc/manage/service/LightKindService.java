package zjc.manage.service;
import zjc.manage.dao.LightkindMapper;
import javax.annotation.Resource;
public class LightKindService {
    @Resource
    private LightkindMapper lightkindMapper;
}


