
#import "DetailController.h"

@interface DetailController ()

@end

@implementation DetailController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.name.text = self.light.name;
    self.price.text=self.light.price;
    self.navigationItem.title=@"详情介绍";
}

@end
