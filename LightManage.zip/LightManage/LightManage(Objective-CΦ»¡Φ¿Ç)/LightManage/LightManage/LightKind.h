#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface LightKind : NSObject
@property(nonatomic,copy)NSString *lightkindname;
@property(nonatomic,copy)NSString *lightkindid;
@property(nonatomic,copy)NSString *picture;
+(instancetype)lightkindWithDict:(NSDictionary *)dict;
-(instancetype)initWithDict:(NSDictionary *)dict;
+(NSArray *)lightkindes;
@end

NS_ASSUME_NONNULL_END
