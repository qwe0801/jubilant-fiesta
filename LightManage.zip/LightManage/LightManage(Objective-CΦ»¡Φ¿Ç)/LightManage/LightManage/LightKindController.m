#import "LightKindController.h"
#import "Light.h"
#import "DetailController.h"
@interface LightKindController ()
@property(nonatomic,strong)NSArray *lights;
@end

@implementation LightKindController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.tableView.rowHeight=90;
    self.navigationItem.title=@"灯光列表";
    
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}
-(NSArray *)lights{
    if (!_lights) {
        _lights=[Light lights];
    }
    return _lights;
}

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    //获取跳转的目的的控制器
    UIViewController *vc=segue.destinationViewController;
    //判断是否是目的控制器
    if ([vc isKindOfClass:[DetailController class]]) {
        DetailController *detailVc=(DetailController *)vc;
        //获取单击行所在的索引
        NSIndexPath *Path=[self.tableView indexPathForSelectedRow];
        //选中行的模型
        Light *light=self.lights[Path.row];
        detailVc.light=light;
    }
}
-(void) tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [self performSegueWithIdentifier:@"two" sender:self];
}



#pragma mark - UITableViewDataSource
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.lights.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    NSString *ID=@"lightid";
    UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:ID];
    if (cell==nil) {
        cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:ID];
    }
    //设置cell
    Light *light=self.lights[indexPath.row];
    cell.textLabel.text=light.name;
    cell.imageView.image=[UIImage imageNamed:light.picture];
    cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
    return cell;

}

@end
