
//  Created by god cat on 2021/7/2.
//

#import "LightKind.h"
@interface LightKind()
@property(nonatomic,copy)NSArray *lightkindArray;
@end

@implementation LightKind
+(instancetype)lightkindWithDict:(NSDictionary *)dict{
    return [[self alloc]initWithDict:dict];
}
-(instancetype)initWithDict:(NSDictionary *)dict{
    if (self=[super init]) {
        [self setValuesForKeysWithDictionary:dict];
    }
    return self;
}
+(NSArray *)lightkindes{
    NSString *path=[[NSBundle mainBundle]pathForResource:@"LightKindList.plist" ofType:nil];
    NSArray *arr=[NSArray arrayWithContentsOfFile:path];
    NSMutableArray *mutableArray=[NSMutableArray array];
    for (NSDictionary *dic in arr) {
        [mutableArray addObject:[LightKind lightkindWithDict:dic]];
    }
    return mutableArray;
}

@end
