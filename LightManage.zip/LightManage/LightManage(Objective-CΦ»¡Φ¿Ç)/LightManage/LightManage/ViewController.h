//
//  ViewController.h
//  LightManage
//
//  Created by qwe on 2021/7/4.
//

#import <UIKit/UIKit.h>

@interface ViewController : UITableViewController


@end

