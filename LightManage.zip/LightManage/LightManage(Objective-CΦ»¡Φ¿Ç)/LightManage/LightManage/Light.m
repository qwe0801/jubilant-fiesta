#import "Light.h"
@interface Light()
@property (nonatomic,copy)NSArray *lightArray;
@end
@implementation Light
+(instancetype)lightWithDict:(NSDictionary *)dict{
    return [[self alloc]initWithDict:dict];
}
-(instancetype)initWithDict:(NSDictionary *)dict{
    if (self=[super init]) {
        [self setValuesForKeysWithDictionary:dict];
    }
    return self;
}
+(NSArray *)lights{
    NSString *path=[[NSBundle mainBundle]pathForResource:@"LightList.plist" ofType:nil];
    //获取数组中的元素
    NSArray *arr=[NSArray arrayWithContentsOfFile:path];
    NSMutableArray *mutableArray=[NSMutableArray array];
    for (NSDictionary *dic in arr) {
        [mutableArray addObject:[Light lightWithDict:dic]];
    }
    return mutableArray;
}
@end
