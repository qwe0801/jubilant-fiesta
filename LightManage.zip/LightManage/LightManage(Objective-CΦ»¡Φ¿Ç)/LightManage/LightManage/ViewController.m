//
//  ViewController.m
//  LightManage
//
//  Created by qwe on 2021/7/4.
//

#import "ViewController.h"
#import "LightKind.h"
#import "LightKindController.h"
@interface ViewController ()
@property(nonatomic,strong)NSArray *lightkindes;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.tableView.rowHeight=90;
    self.navigationItem.title=@"灯光分类列表";
}
-(NSArray *)lightkindes{
    if (!_lightkindes) {
        _lightkindes=[LightKind lightkindes];
    }
    return _lightkindes;
}
-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    //获取跳转的目的的控制器
    UIViewController *vc=segue.destinationViewController;
    //判断是否是目的控制器
    if ([vc isKindOfClass:[LightKindController class]]) {
        LightKindController *detailVc=(LightKindController *)vc;
        //获取单击行所在的索引
        NSIndexPath *Path=[self.tableView indexPathForSelectedRow];
        //选中行的模型
        LightKind *lightkind=self.lightkindes[Path.row];
        detailVc.lightkind=lightkind;
    }
}
#pragma mark - UITableViewDelegate
-(void) tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [self performSegueWithIdentifier:@"one" sender:self];
}
#pragma mark - UITableViewDataSource
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.lightkindes.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    NSString *ID=@"lightkindid";
    UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:ID];
    if (cell==nil) {
        cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:ID];
    }
    //设置cell
    LightKind *lightkind=self.lightkindes[indexPath.row];
    cell.textLabel.text=lightkind.lightkindname;
    cell.imageView.image=[UIImage imageNamed:lightkind.picture];
    cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
    return cell;
}

@end
