//
//  SceneDelegate.h
//  LightManage
//
//  Created by qwe on 2021/7/4.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

