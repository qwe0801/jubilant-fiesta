//

//
//  Created by god cat on 2021/7/2.
//

#import <UIKit/UIKit.h>
#import "Light.h"
NS_ASSUME_NONNULL_BEGIN

@interface DetailController : UIViewController
@property (weak, nonatomic) IBOutlet UILabel *name;
@property (weak, nonatomic) IBOutlet UITextView *price;


@property (nonatomic,strong)Light *light;
@end

NS_ASSUME_NONNULL_END
