#import <UIKit/UIKit.h>
#import "LightKind.h"
NS_ASSUME_NONNULL_BEGIN

@interface LightKindController : UITableViewController
@property (nonatomic,strong)LightKind *lightkind;
@end

NS_ASSUME_NONNULL_END
