/*
 Navicat Premium Data Transfer

 Source Server         : lll
 Source Server Type    : MySQL
 Source Server Version : 50730
 Source Host           : localhost:3306
 Source Schema         : lightmanage

 Target Server Type    : MySQL
 Target Server Version : 50730
 File Encoding         : 65001

 Date: 23/03/2023 16:07:58
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for Light
-- ----------------------------
DROP TABLE IF EXISTS `Light`;
CREATE TABLE `Light` (
  `LightID` int(11) NOT NULL AUTO_INCREMENT,
  `LightKindID` int(11) DEFAULT NULL,
  `LightName` varchar(255) DEFAULT NULL,
  `LightPrice` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`LightID`),
  KEY `LightKindID` (`LightKindID`),
  CONSTRAINT `light_ibfk_1` FOREIGN KEY (`LightKindID`) REFERENCES `LightKind` (`LightKindID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Light
-- ----------------------------
BEGIN;
INSERT INTO `Light` VALUES (1, 1, '流浪地球', '20');
INSERT INTO `Light` VALUES (2, 2, '少年的你', '1000');
INSERT INTO `Light` VALUES (3, 3, '中途岛', '200');
INSERT INTO `Light` VALUES (4, 4, '你的名字', '2000');
INSERT INTO `Light` VALUES (5, 5, '建党大业', '100');
COMMIT;

-- ----------------------------
-- Table structure for LightKind
-- ----------------------------
DROP TABLE IF EXISTS `LightKind`;
CREATE TABLE `LightKind` (
  `LightKindID` int(11) NOT NULL AUTO_INCREMENT,
  `LightKindName` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`LightKindID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of LightKind
-- ----------------------------
BEGIN;
INSERT INTO `LightKind` VALUES (1, '科幻片');
INSERT INTO `LightKind` VALUES (2, '爱情片');
INSERT INTO `LightKind` VALUES (3, '战争片');
INSERT INTO `LightKind` VALUES (4, '动画片');
INSERT INTO `LightKind` VALUES (5, '历史片');
COMMIT;

SET FOREIGN_KEY_CHECKS = 1;
